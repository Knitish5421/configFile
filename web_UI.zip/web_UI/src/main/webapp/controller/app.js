var app = angular.module("loginApp", ['ui.router','ngGrid']);
app.config(function($stateProvider, $urlRouterProvider) {
	
$urlRouterProvider.otherwise('/login');	

$stateProvider
.state('login', { 
    url : '/login', 
    templateUrl : "pages/login.html", 
    controller : "loginController"
}) 

})