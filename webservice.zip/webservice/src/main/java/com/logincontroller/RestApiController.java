package com.logincontroller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mapper.dao.EmployeeMapper;
import com.model.Check;
import com.model.Employee;
import com.model.Login;

@Controller
public class RestApiController {
  EmployeeMapper employeeMapper = new EmployeeMapper();
	
	@RequestMapping( value= "/login")
	public String index(@RequestBody Login login, HttpServletRequest req) 
	{
		List<Employee> list = employeeMapper.getAllEmployees();
        Check ln=new Check();
		String username = "Nitish";
		String  password = "kumar";
		if(login.getUsername().equalsIgnoreCase(username)&&login.getPassword().equalsIgnoreCase(password)) {
			ln.setCondition("suceess");
			return "ok";
		}
		ln.setCondition("fail");
		return "nk";
	}
	
	
/*	public ResponseEntity<Check> login(@RequestBody Login login, HttpServletRequest req)
			{ 
        Check ln=new Check();
		String username = "Nitish";
		String  password = "kumar";
		if(login.getUsername().equalsIgnoreCase(username)&&login.getPassword().equalsIgnoreCase(password)) {
			ln.setCondition("suceess");
			return new ResponseEntity<Check>(ln, HttpStatus.OK);
		}
		ln.setCondition("fail");
		return new ResponseEntity<Check>(ln, HttpStatus.OK);
	}
	*/
}
