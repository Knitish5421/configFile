package com.mapper.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Iterator;
import java.util.List;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonReader;

import org.apache.ibatis.session.SqlSession;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.json.JSONArray;
import org.springframework.stereotype.Service;

import com.exception.RecordNotFoundException;
import com.model.Employee;
import com.mybatis.config.MyBatisUtil;
@Service
public class EmployeeMapper {
	
	
	public List<Employee> getAllEmployees() {
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		List<Employee> list = session.selectList("EmployeeMapper.getAllEmployees");
		session.commit();
		session.close();
	    return list; 
	}
	
	public void deletById(Long id)throws RecordNotFoundException
	{
		SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
		session.delete("EmployeeMapper.deleteById", id);
		session.commit();
		session.close();
	}
	

	public Integer deletById1(Long id)
	{
		SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
		Integer ids=session.delete("EmployeeMapper.deleteById", id);
		session.commit();
		session.close();
		return ids;
	}
	
	
	
	
public Employee getDataById(Long id) {
	SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
	Employee employee = session.selectOne("EmployeeMapper.getById",id );
	session.commit();
	session.close();
	return employee;
	
}
	
public Integer updateById(Employee employee)
{
	SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
	Integer i=session.update("EmployeeMapper.update",employee );
	session.commit();
	session.close();
	return i;
	
}

public void insertEmployee(Employee employee) throws RecordNotFoundException
{
SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
session.insert("EmployeeMapper.insert",employee );
session.commit();
session.close();
}

public Integer insert(Employee employee) 
{
SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
Integer emp=session.insert("EmployeeMapper.insert",employee );
session.commit();
session.close();
return emp;
}

public List<Employee> getFnameLname( String firstname) {
	SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
	 List<Employee> employeeList  = session.selectList("EmployeeMapper.getFirstLastName",firstname);
	session.commit();
	session.close();
    return employeeList; 
}

public void exportJSON() {
	SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
	List<Employee> list = session.selectList("EmployeeMapper.getAllEmployees");

	OutputStreamWriter writer = null;
	FileOutputStream fileStream = null;
	JSONArray jsonArray = new JSONArray(list);
	String jsonString = "";
	if (jsonArray.length() > 0) {
		jsonString = jsonArray.toString();
	}
	System.out.println(jsonString);
	File file = new File("C:\\Users\\kniti\\Downloads\\json");

	try {
		fileStream = new FileOutputStream(file);
		writer = new OutputStreamWriter(fileStream, "UTF-8");
		writer.write(jsonString);
		writer.flush();
	} catch (IOException var20) {
		var20.printStackTrace();
	} finally {
		if (writer != null) {
			try {
				writer.close();
			} catch (IOException var19) {
				var19.printStackTrace();
			}
		}

		if (fileStream != null) {
			try {
				fileStream.close();
			} catch (IOException var18) {
				var18.printStackTrace();
			}
		}

	}
}

public void importJSON(String string) {
	JsonReader reader = null;
	List<Employee> participantJsonList=null;
	try {
		reader = Json.createReader(new FileInputStream(new File(string)));
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 	
	ObjectMapper mapper = new ObjectMapper();
	JsonArray array = reader.readArray();
	try {
		participantJsonList = mapper.readValue(array.toString(), new TypeReference<List<Employee>>(){});
	} catch (JsonParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (JsonMappingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	Iterator <Employee> itr=participantJsonList.iterator();
	while (itr.hasNext()) {
		Employee employee =  itr.next();
		SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
		Integer emp=session.insert("EmployeeMapper.insert",employee );
		session.commit();
		session.close();
		
	}
}

public void excelExport() {
	FileOutputStream out = null;
	SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
	List<Employee> list = session.selectList("EmployeeMapper.getAllEmployees");
	XSSFWorkbook workbook = new XSSFWorkbook();
	XSSFSheet spreadsheet = workbook.createSheet("excels");
	XSSFRow row = spreadsheet.createRow(1);
	XSSFCell cell = row.createCell(1);
	cell.setCellValue("firstname");
	cell = row.createCell(2);
	cell.setCellValue("lastname");
	cell = row.createCell(3);
	cell.setCellValue("gender");
	cell = row.createCell(4);
	cell.setCellValue("age");
	cell = row.createCell(5);
	cell.setCellValue("date");
	cell = row.createCell(6);
	cell.setCellValue("salary");
	cell = row.createCell(7);
	cell.setCellValue("DeptName");
	cell = row.createCell(8);
	cell.setCellValue("state");
	cell = row.createCell(9);
	cell.setCellValue("city");
	cell = row.createCell(10);
	cell.setCellValue("skills");
	cell = row.createCell(11);
	cell.setCellValue("address ");
	
	int i = 2;
	Employee emp=null;
	for (Iterator<Employee> itr = list.iterator(); itr.hasNext(); ++i) {
		emp = itr.next();
		row = spreadsheet.createRow(i);
		cell = row.createCell(1);
		cell.setCellValue(emp.getFirstname());
		cell = row.createCell(2);
		cell.setCellValue(emp.getLastname());
		cell = row.createCell(3);
		cell.setCellValue(emp.getGender());
		cell = row.createCell(4);
		cell.setCellValue(emp.getAge());
		cell = row.createCell(5);
		cell.setCellValue(emp.getDate());
		cell = row.createCell(6);
		cell.setCellValue(emp.getSalary());
		cell = row.createCell(7);
		cell.setCellValue(emp.getDeptName());
		cell = row.createCell(8);
		cell.setCellValue(emp.getState());
		cell = row.createCell(9);
		cell.setCellValue(emp.getCity());
		cell = row.createCell(10);
		cell.setCellValue(emp.getSkills());
		cell = row.createCell(11);
		cell.setCellValue(emp.getAddress());	
	}

	try {
		out = new FileOutputStream(new File("C:\\Users\\kniti\\Downloads\\EX.xlsx"));
	} catch (FileNotFoundException var21) {
		var21.printStackTrace();
	}

	try {
		workbook.write(out);
	} catch (IOException var20) {
		var20.printStackTrace();
	} finally {
		if (out != null) {
			try {
				out.close();
			} catch (IOException var19) {
				var19.printStackTrace();
			}
		}

	}

	
}


public boolean importExcel(String string) {

	try {
		FileInputStream file = new FileInputStream(new File(string));
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheetAt(0);
      Employee emp=null;
		for (Iterator<Row> rowIterator = sheet.iterator(); rowIterator.hasNext();) {
			emp = new Employee();
			Row row =  rowIterator.next();
			if (row.getRowNum() !=0) {
				System.out.println(row.getRowNum());
				Iterator<Cell> cellIterator = row.cellIterator();

					while (cellIterator.hasNext()) {
						Cell cell =  cellIterator.next();
						int columnIndex = cell.getColumnIndex();
						int cellType;
						if (columnIndex == 0) {
							cellType = cell.getCellType();
							if (cellType == 1) {
								emp.setFirstname(cell.getStringCellValue());
							}
						} 
						else if (columnIndex == 1) {
								cellType = cell.getCellType();
								if (cellType == 1) {
									emp.setLastname(cell.getStringCellValue());
								
							} 
						}
						else if (columnIndex == 2) {
							cellType = cell.getCellType();
							if (cellType == 1) {
								emp.setGender(cell.getStringCellValue());
							
						} 
					}
						else if (columnIndex == 3) {
							cellType = cell.getCellType();
							if (cellType == 0) {
								emp.setAge((int)cell.getNumericCellValue());
							
						} 
					}
						else if (columnIndex == 4) {
							cellType = cell.getCellType();
							if (cellType == 1) {
								emp.setDate(cell.getStringCellValue());
							
						} 
					}
						else if (columnIndex == 5) {
							cellType = cell.getCellType();
							if (cellType == 0) {
								emp.setSalary(cell.getNumericCellValue());
							
						} 
					}
						else if (columnIndex == 6) {
							cellType = cell.getCellType();
							if (cellType == 1) {
								emp.setDeptName(cell.getStringCellValue());
							
						} 
					}
						else if (columnIndex == 7) {
							cellType = cell.getCellType();
							if (cellType == 1) {
								emp.setState(cell.getStringCellValue());
							
						} 
					}
						else if (columnIndex == 8) {
							cellType = cell.getCellType();
							if (cellType == 1) {
								emp.setCity(cell.getStringCellValue());
							
						} 
					}
						else if (columnIndex == 9) {
							cellType = cell.getCellType();
							if (cellType == 1) {
								emp.setSkills(cell.getStringCellValue());
							
						} 
					}
						else if (columnIndex == 10) {
							cellType = cell.getCellType();
							if (cellType == 1) {
								emp.setAddress(cell.getStringCellValue());
							
						} 
					}
					}
					SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
					Integer emp1 =session.insert("EmployeeMapper.insert",emp  );
					session.commit();
					session.close();
			}
			
		}

		file.close();
	} catch (IOException var40) {
		System.out.println(var40);
		var40.printStackTrace();
	}

	return true;
	
}




















}




