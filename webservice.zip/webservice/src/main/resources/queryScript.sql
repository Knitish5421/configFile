create database employees;

create table  Employee (id int(10) AUTO_INCREMENT primary key,first_name varchar(50), last_name varchar(50), gender varchar(50),date varchar(50), age int,
salary int,DeptName varchar(50),state varchar(50) ,city varchar(50) ,skills varchar(50),address varchar(50));